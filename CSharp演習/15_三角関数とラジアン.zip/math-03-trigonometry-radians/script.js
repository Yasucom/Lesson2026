"use strict";

if ("IntersectionObserver" in window) {
  const links = [...document.querySelectorAll(".sidebar nav a")];
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          links.forEach((a) => {
            if (a.hash === `#${entry.target.id}`)
              a.setAttribute("aria-current", "location");
            else a.removeAttribute("aria-current");
          });
        }
      }
    },
    { rootMargin: "-12% 0px -65% 0px", threshold: 0 },
  );
  document
    .querySelectorAll("main section")
    .forEach((section) => observer.observe(section));
}

const angleInput = document.getElementById("angle-input");
const radiusInput = document.getElementById("radius-input");
const angleOutput = document.getElementById("angle-output");
function updateAngle() {
  if (
    !angleInput.value ||
    !radiusInput.value ||
    !angleInput.validity.valid ||
    !radiusInput.validity.valid
  ) {
    angleOutput.textContent =
      "角度は−360〜720、半径は0〜20で入力してください。";
    return;
  }
  const rad = (Number(angleInput.value) * Math.PI) / 180;
  const radius = Number(radiusInput.value);
  const x = Math.cos(rad),
    y = Math.sin(rad);
  const fmt = (value) =>
    (Math.abs(value) < 0.00005 ? 0 : value).toFixed(4).replace(/\.?0+$/, "");
  angleOutput.textContent = `${angleInput.value}°＝${fmt(rad)} rad。方向(${fmt(x)}, ${fmt(y)})、半径${radius}の位置は(${fmt(x * radius)}, ${fmt(4 + y * radius)})です。`;
}
angleInput.addEventListener("input", updateAngle);
radiusInput.addEventListener("input", updateAngle);
document.querySelectorAll("[data-angle]").forEach((button) =>
  button.addEventListener("click", () => {
    angleInput.value = button.dataset.angle;
    updateAngle();
  }),
);
updateAngle();
