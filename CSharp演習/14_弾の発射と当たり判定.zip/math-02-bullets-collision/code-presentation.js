"use strict";

(() => {
  const codeBlocks = [...document.querySelectorAll("pre code")];

  // Install protection before calculating differences, so a comparison error
  // cannot disable normal copy and selection protection.
  function inCode(target) {
    const element = target instanceof Element ? target : target?.parentElement;
    return Boolean(element?.closest("pre"));
  }

  function selectionTouchesCode() {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed) return false;
    for (let i = 0; i < selection.rangeCount; i++) {
      const range = selection.getRangeAt(i);
      if (codeBlocks.some((code) => range.intersectsNode(code))) return true;
    }
    return false;
  }

  function copyingCode(event) {
    return (
      inCode(event.target) ||
      inCode(document.activeElement) ||
      selectionTouchesCode()
    );
  }

  for (const type of ["selectstart", "dragstart", "contextmenu"]) {
    document.addEventListener(
      type,
      (event) => {
        if (inCode(event.target)) event.preventDefault();
      },
      true,
    );
  }
  for (const type of ["copy", "cut"]) {
    document.addEventListener(
      type,
      (event) => {
        if (copyingCode(event)) {
          event.preventDefault();
          event.stopImmediatePropagation();
          event.clipboardData?.clearData();
        }
      },
      true,
    );
  }
  document.addEventListener(
    "keydown",
    (event) => {
      const key = event.key.toLowerCase();
      const copyShortcut =
        (event.ctrlKey || event.metaKey) && ["c", "x", "insert"].includes(key);
      const cutShortcut = event.shiftKey && key === "delete";
      const selectAllCode =
        (event.ctrlKey || event.metaKey) && key === "a" && inCode(event.target);
      if (
        selectAllCode ||
        ((copyShortcut || cutShortcut) && copyingCode(event))
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    },
    true,
  );

  // Find additions and changes compared with the preceding related lesson example.
  function changedLines(previous, current) {
    const before = previous.split("\n").map((line) => line.trim());
    const after = current.split("\n").map((line) => line.trim());
    const lengths = Array.from(
      { length: before.length + 1 },
      () => new Uint32Array(after.length + 1),
    );

    for (let i = before.length - 1; i >= 0; i--) {
      for (let j = after.length - 1; j >= 0; j--) {
        lengths[i][j] =
          before[i] === after[j]
            ? lengths[i + 1][j + 1] + 1
            : Math.max(lengths[i + 1][j], lengths[i][j + 1]);
      }
    }

    const changed = new Set();
    let i = 0;
    let j = 0;
    while (j < after.length) {
      if (i < before.length && before[i] === after[j]) {
        i++;
        j++;
      } else if (i < before.length && lengths[i + 1][j] >= lengths[i][j + 1]) {
        i++;
      } else {
        changed.add(j++);
      }
    }
    return changed;
  }

  // A replacement snippet can be compared with the corresponding method
  // in an earlier complete file, without marking the surrounding class.
  function comparisonRange(text, scope = "all") {
    const lines = text.split("\n");
    if (scope === "all") return { text, offset: 0 };
    const [name, kind] = scope.split("-");
    const signature = new RegExp(
      "^\\s*(?:(?:public|private|protected|internal|static|virtual|override|sealed|async|new|partial)\\s+)*[\\w<>\\[\\],.?]+\\s+" +
        name +
        "\\s*\\([^)]*\\)\\s*(?:\\{|$)",
    );
    const first = lines.findIndex((line) => signature.test(line));
    if (first < 0) return null;
    let depth = 0;
    let opening = -1;
    for (let i = first; i < lines.length; i++) {
      for (const character of lines[i]) {
        if (character === "{") {
          if (opening < 0) opening = i;
          depth++;
        } else if (character === "}") {
          depth--;
          if (opening >= 0 && depth === 0) {
            const begin = kind === "body" ? opening + 1 : first;
            const end = kind === "body" ? i : i + 1;
            return { text: lines.slice(begin, end).join("\n"), offset: begin };
          }
        }
      }
    }
    return null;
  }

  for (const code of codeBlocks) {
    const previousCode = document.getElementById(code.dataset.codePrevious);
    if (!previousCode) continue;
    const current = code.textContent;
    const previousRange = comparisonRange(
      previousCode.textContent,
      code.dataset.comparePrevious,
    );
    const currentRange = comparisonRange(current, code.dataset.compareCurrent);
    if (!previousRange || !currentRange) continue;

    const localChanges = changedLines(previousRange.text, currentRange.text);
    const changed = new Set(
      [...localChanges].map((index) => index + currentRange.offset),
    );
    const fragment = document.createDocumentFragment();
    const lines = current.split("\n");
    let highlighted = false;
    lines.forEach((line, index) => {
      if (changed.has(index) && line.trim().length) {
        const span = document.createElement("span");
        span.className = "code-change";
        span.textContent = line;
        fragment.append(span);
        highlighted = true;
      } else {
        fragment.append(document.createTextNode(line));
      }
      if (index < lines.length - 1)
        fragment.append(document.createTextNode("\n"));
    });
    code.replaceChildren(fragment);
    if (highlighted) {
      const label = code.closest(".code-block")?.querySelector(".code-label");
      if (label && !label.querySelector(".code-diff-label")) {
        const explanation = document.createElement("span");
        explanation.className = "code-diff-label";
        explanation.textContent = "黄色：前の関連コードから追加・変更した行";
        label.append(explanation);
      }
    }
  }

  for (const code of codeBlocks) {
    if (code.querySelector(".code-line")) continue;
    const lines = code.innerHTML.split("\n");
    const fragment = document.createDocumentFragment();
    lines.forEach((html, index) => {
      const line = document.createElement("span");
      line.className = "code-line";
      line.dataset.line = String(index + 1);
      line.innerHTML = html;
      fragment.append(line);
      if (index < lines.length - 1)
        fragment.append(document.createTextNode("\n"));
    });
    code.replaceChildren(fragment);
  }
})();
