"use strict";

if ("IntersectionObserver" in window) {
  const links = [...document.querySelectorAll(".sidebar nav a")];
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          links.forEach((a) => {
            if (a.hash === `#${entry.target.id}`)
              a.setAttribute("aria-current", "location");
            else a.removeAttribute("aria-current");
          });
        }
      }
    },
    { rootMargin: "-12% 0px -65% 0px", threshold: 0 },
  );
  document
    .querySelectorAll("main section")
    .forEach((section) => observer.observe(section));
}

