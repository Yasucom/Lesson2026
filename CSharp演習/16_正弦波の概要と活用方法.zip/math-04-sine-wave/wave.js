"use strict";

// Keep the embedded PowerPoint animation intact. Stopping shows its first frame.
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
const gif = document.getElementById("sine-gif");
const gifToggle = document.getElementById("gif-toggle");
const gifStatus = document.getElementById("gif-status");
let gifPlaying = !reducedMotion.matches;
function showGifState() {
  gif.src = gifPlaying
    ? "assets/sine-motion.gif"
    : "assets/sine-motion-still.webp";
  gifToggle.textContent = gifPlaying ? "動く図を止める" : "動く図を再生する";
  gifToggle.setAttribute("aria-pressed", String(!gifPlaying));
  gifStatus.textContent = gifPlaying
    ? "繰り返し再生中"
    : "先頭の静止画を表示中";
}
gifToggle.addEventListener("click", () => {
  gifPlaying = !gifPlaying;
  showGifState();
});
showGifState();

const lab = document.getElementById("wave-lab");
const canvas = document.getElementById("wave-canvas");
const ctx = canvas.getContext("2d");
const inputs = {
  amplitude: document.getElementById("wave-amplitude"),
  period: document.getElementById("wave-period"),
  offset: document.getElementById("wave-offset"),
  count: document.getElementById("wave-count"),
};
const timeInput = document.getElementById("wave-time");
const timeValue = document.getElementById("wave-time-value");
const toggle = document.getElementById("wave-toggle");
const readout = document.getElementById("wave-readout");
const message = document.getElementById("wave-message");
const presets = [...document.querySelectorAll("[data-wave-preset]")];
let time = 0;
let playing = false;
let visible = true;
let width = 800;
const height = 620;
let previousStamp = performance.now();
let config = { amplitude: 90, period: 8, offset: 0, count: 1 };

function format(value, places = 3) {
  const rounded = Math.abs(value) < 0.0005 ? 0 : value;
  return Number(rounded.toFixed(places)).toString();
}
function setPlaying(next) {
  playing = next;
  toggle.textContent = playing ? "動きを止める" : "動きを再生する";
  toggle.setAttribute("aria-pressed", String(playing));
  previousStamp = performance.now();
}
function line(x1, y1, x2, y2, color, stroke = 1) {
  ctx.strokeStyle = color;
  ctx.lineWidth = stroke;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}
function label(text, x, y, align = "left", color = "#34453e") {
  ctx.fillStyle = color;
  ctx.font = "13px system-ui, -apple-system, sans-serif";
  ctx.textAlign = align;
  ctx.fillText(text, x, y);
}
function arrow(cx, cy, angle, radius, color) {
  const rad = (angle * Math.PI) / 180;
  const dx = Math.cos(rad),
    dy = -Math.sin(rad);
  const x = cx + dx * radius,
    y = cy + dy * radius;
  line(cx, cy, x, y, color, 2);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x - dx * 11 - dy * 5, y - dy * 11 + dx * 5);
  ctx.lineTo(x - dx * 11 + dy * 5, y - dy * 11 - dx * 5);
  ctx.closePath();
  ctx.fill();
}
function draw() {
  if (!ctx) return;
  const phase = time / config.period;
  const value = Math.sin(phase * Math.PI * 2);
  const base = value * config.amplitude + config.offset;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, width, height);

  label("正弦波の1周期（縦：Sinの値）", 18, 28);
  const left = 48,
    right = width - 24,
    top = 58,
    bottom = 215;
  const mid = (top + bottom) / 2,
    amp = (bottom - top) / 2;
  for (const y of [-1, 0, 1]) {
    const yy = mid - y * amp;
    line(left, yy, right, yy, "#dfe7e0");
    label(String(y), left - 12, yy + 4, "right");
  }
  for (let i = 0; i <= 4; i++) {
    const x = left + ((right - left) * i) / 4;
    line(x, top, x, bottom, "#edf0ed");
    label(`${format((config.period * i) / 4)}秒`, x, bottom + 23, "center");
  }
  ctx.strokeStyle = "#19745a";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  for (let i = 0; i <= 250; i++) {
    const fraction = i / 250;
    const x = left + (right - left) * fraction;
    const y = mid - Math.sin(fraction * Math.PI * 2) * amp;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
  const px = left + (right - left) * phase,
    py = mid - value * amp;
  ctx.setLineDash([4, 4]);
  line(px, top, px, bottom, "#c47b16");
  ctx.setLineDash([]);
  ctx.beginPath();
  ctx.fillStyle = "#c47b16";
  ctx.arc(px, py, 5.5, 0, Math.PI * 2);
  ctx.fill();

  label("現在の発射方向（右が0°、上が90°）", 18, 275);
  const cx = width / 2,
    cy = 431;
  const radius = Math.min(125, (width - 85) / 2);
  ctx.beginPath();
  ctx.strokeStyle = "#dfe7e0";
  ctx.lineWidth = 1;
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.stroke();
  line(cx - radius - 12, cy, cx + radius + 12, cy, "#d1ddd5");
  line(cx, cy - radius - 12, cx, cy + radius + 12, "#d1ddd5");
  label("+X", cx + radius + 15, cy - 5, "center");
  label("+Y", cx + 9, cy - radius - 13);
  for (let i = 0; i < config.count; i++) {
    // The 12-way source increments before firing; the opposite pair uses base/base+180.
    const step = config.count > 2 ? i + 1 : i;
    const angle = base + (step * 360) / config.count;
    arrow(cx, cy, angle, radius, i === 0 ? "#1976a3" : "#21825e");
  }
  ctx.fillStyle = "#b84840";
  ctx.fillRect(cx - 6, cy - 6, 12, 12);
  label(
    `基準角度 ${format(base, 2)}° ／ ${config.count}方向`,
    cx,
    591,
    "center",
  );
  timeInput.value = time.toFixed(2);
  timeValue.textContent = `${time.toFixed(2)}秒 / ${config.period}秒`;
  readout.textContent = `波の値 ${format(value)} × 振幅${config.amplitude}° ＋ 中心${config.offset}° ＝ 基準角度${format(base, 2)}°。振動数は${format(1 / config.period)} Hz、方向の間隔は${format(360 / config.count, 2)}°です。`;
  canvas.dataset.baseAngle = base.toFixed(6);
  canvas.dataset.sineValue = value.toFixed(6);
  canvas.dataset.time = time.toFixed(4);
}
function resize() {
  const bounds = canvas.getBoundingClientRect();
  width = Math.max(200, bounds.width);
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  canvas.style.height = `${height}px`;
  ctx?.setTransform(ratio, 0, 0, ratio, 0, 0);
  draw();
}
function readConfig() {
  if (
    Object.values(inputs).some(
      (input) => input.value === "" || !input.validity.valid,
    )
  ) {
    setPlaying(false);
    message.textContent =
      "振幅は0〜180、周期は0.5〜12、中心角度は−360〜360、方向数は1〜24の範囲で入力してください。";
    return;
  }
  config = Object.fromEntries(
    Object.entries(inputs).map(([name, input]) => [name, Number(input.value)]),
  );
  message.textContent = "";
  time = Math.min(time, config.period);
  timeInput.max = String(config.period);
  presets.forEach((button) => button.setAttribute("aria-pressed", "false"));
  draw();
}
Object.values(inputs).forEach((input) =>
  input.addEventListener("input", readConfig),
);
timeInput.addEventListener("input", () => {
  setPlaying(false);
  time = Number(timeInput.value);
  draw();
});
toggle.addEventListener("click", () => {
  if (
    Object.values(inputs).some(
      (input) => input.value === "" || !input.validity.valid,
    )
  ) {
    readConfig();
    return;
  }
  setPlaying(!playing);
});
document.getElementById("wave-reset").addEventListener("click", () => {
  setPlaying(false);
  time = 0;
  draw();
});
presets.forEach((button) =>
  button.addEventListener("click", () => {
    const mode = button.dataset.wavePreset;
    inputs.amplitude.value = "90";
    inputs.offset.value = "0";
    inputs.period.value = mode === "twelve" ? "4" : "8";
    inputs.count.value =
      mode === "single" ? "1" : mode === "opposite" ? "2" : "12";
    time = 0;
    setPlaying(false);
    readConfig();
    button.setAttribute("aria-pressed", "true");
  }),
);
if ("ResizeObserver" in window) new ResizeObserver(resize).observe(lab);
else window.addEventListener("resize", resize);
if ("IntersectionObserver" in window) {
  new IntersectionObserver((entries) => {
    visible = entries[0].isIntersecting;
    previousStamp = performance.now();
  }).observe(lab);
}
function animate(stamp) {
  const delta = Math.min((stamp - previousStamp) / 1000, 0.1);
  previousStamp = stamp;
  if (playing && visible && !document.hidden) {
    time = (time + delta) % config.period;
    draw();
  }
  requestAnimationFrame(animate);
}
readConfig();
resize();
requestAnimationFrame(animate);
