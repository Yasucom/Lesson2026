"use strict";

if ("IntersectionObserver" in window) {
  const links = [...document.querySelectorAll(".sidebar nav a")];
  const observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          links.forEach((a) => {
            if (a.hash === `#${entry.target.id}`)
              a.setAttribute("aria-current", "location");
            else a.removeAttribute("aria-current");
          });
        }
      }
    },
    { rootMargin: "-12% 0px -65% 0px", threshold: 0 },
  );
  document
    .querySelectorAll("main section")
    .forEach((section) => observer.observe(section));
}

const objectCount = document.getElementById("object-count");
const pairOutput = document.getElementById("pair-output");
function updatePairs() {
  if (!objectCount.value || !objectCount.validity.valid) {
    pairOutput.textContent = "2〜10000の整数を入力してください。";
    return;
  }
  const n = Number(objectCount.value);
  pairOutput.textContent = `${n.toLocaleString("ja-JP")}個なら${((n * (n - 1)) / 2).toLocaleString("ja-JP")}組。1体と残りだけを比べるなら${(n - 1).toLocaleString("ja-JP")}回です。`;
}
objectCount.addEventListener("input", updatePairs);
updatePairs();
